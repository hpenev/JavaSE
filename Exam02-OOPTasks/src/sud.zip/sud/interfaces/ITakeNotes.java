package sud.interfaces;

public interface ITakeNotes {

    public void takeNotes();

}
