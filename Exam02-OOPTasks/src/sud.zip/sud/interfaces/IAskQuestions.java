package sud.interfaces;

import sud.objects.citizens.Citizen;

public interface IAskQuestions {

    public void askQuestion(Citizen witness, int numberOfQuestion);

}
