package inClass;

public class StringBuilderExamples {
    public static void main(String[] args) {
	StringBuilder sBuilder = new StringBuilder();
	sBuilder.append("1");
	sBuilder.append("2");
	sBuilder.append("3");
	sBuilder.append("4");
	sBuilder.append("5");

	System.out.println(sBuilder.toString());

	String string = new String();
    }
}
