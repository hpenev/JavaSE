package inClass;

public class MethodsExamples {
    public static void main(String[] args) {

    }

    static void nonReturningMethod() {
	return;
    }

    static int intMethod() {
	return -1;
    }
}
