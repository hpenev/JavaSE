package taskEmployee;

public interface IWorker {

    void work();

    void setCurrentTask(Task task);

    void startWorkingDay();
}
