package homework;

import java.util.LinkedList;
import java.util.Queue;

public class Scheduler {

    private Queue<Task> tasks = new LinkedList<>();

    void main() {
	while (!tasks.isEmpty()) {
	    this.tasks.poll().doWork();
	}
    }

    void push(Task task) {
	this.tasks.offer(task);
    }
}
