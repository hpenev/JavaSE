package homework;

public class Demo {
    public static void main(String[] args) {
	Task work = new Task() {

	    @Override
	    public void doWork() {
		System.out.println("Working...");

	    }
	};

	Task learn = new Task() {

	    @Override
	    public void doWork() {
		System.out.println("Learning...");

	    }
	};

	Task sleep = new Task() {

	    @Override
	    public void doWork() {
		System.out.println("Sleaping...");

	    }
	};

	Task eat = new Task() {

	    @Override
	    public void doWork() {
		System.out.println("Eating...");

	    }
	};

	Scheduler scheduler = new Scheduler();
	scheduler.push(eat);
	scheduler.push(work);
	scheduler.push(learn);
	scheduler.push(sleep);

	scheduler.main();

    }
}
