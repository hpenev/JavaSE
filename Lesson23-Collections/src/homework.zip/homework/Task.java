package homework;

public interface Task {

    public void doWork();

}
