package loopsBookChapter16;

import java.util.Scanner;

public class Task05 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int a = sc.nextInt();
		System.out.print("Enter a number: ");
		int b = sc.nextInt();
		sc.close();

		if (a > 0 && b > 0 && a < 13 && b < 13) {
			int aFactoriel = 1;
			int bFactoriel = 1;

			for (int i = 1; i <= a; i++) {
				aFactoriel *= i;
			}

			for (int i = 1; i <= b; i++) {
				bFactoriel *= i;
			}

			System.out.println(aFactoriel + bFactoriel);
		} else {
			System.out.println("Wrong input");
		}

	}
}
