package arraysHomework;

import java.util.Scanner;

public class Task13 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int number = sc.nextInt();
		sc.close();

		int[] binaryNumber = new int[32];

		for (int i = 0; i < 32; i++) {
			// Here is the key for the tent
			int bit = (number >> (binaryNumber.length - 1 - i)) & 1;
			binaryNumber[i] = bit;
		}

		for (int i = 0; i < binaryNumber.length; i++) {
			System.out.print(binaryNumber[i]);
		}

	}
}
