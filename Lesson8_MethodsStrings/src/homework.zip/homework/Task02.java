package homework;

import java.util.Scanner;

public class Task02 {
    public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);

	System.out.print("Enter two words separated with space: ");

	String firstWord = sc.next();
	String secondWord = sc.next();

	while (!lengthCheck(firstWord) || !lengthCheck(secondWord)) {
	    System.out.print("Enter two words again: ");
	    firstWord = sc.next();
	    secondWord = sc.next();
	}
	sc.close();

	String newFirstWord = secondWord.substring(0, 5) + firstWord.substring(5, firstWord.length());
	String newSecondWord = firstWord.substring(0, 5) + secondWord.substring(5, secondWord.length());

	System.out
		.print(newFirstWord.length() > newSecondWord.length() ? newFirstWord.length() : newSecondWord.length());
	System.out.print(" ");

	System.out
		.println(newFirstWord.length() > newSecondWord.length() ? newFirstWord : newSecondWord);

    }

    static boolean lengthCheck(String str) {
	if (str.length() > 5 && str.length() <= 20) {
	    return true;
	} else {
	    return false;
	}
    }
}
