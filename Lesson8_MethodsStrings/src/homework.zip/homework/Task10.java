package homework;

import java.util.Scanner;

public class Task10 {
    public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);
	System.out.print("Enter a word: ");
	String string = sc.nextLine();
	sc.close();

	String newString = new String();

	for (int i = 0; i < string.length(); i++) {
	    newString += (char) (string.charAt(i) + 5);
	}

	System.out.print(newString);
    }
}
