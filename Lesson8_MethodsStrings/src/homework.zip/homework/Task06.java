package homework;

import java.util.Scanner;

public class Task06 {
    public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);
	System.out.print("Enter a sentance: ");

	String input = sc.nextLine();
	sc.close();

	System.out.println("Capitalizing the first letter of each word.");

	int start = 0;
	for (int i = 0; i < input.length(); i++) {
	    if (input.charAt(i) == ' ') {
		System.out.print(input.substring(start, start + 1).toUpperCase() + input.substring(start + 1, i + 1));
		start = i + 1;
	    }

	    if (i == input.length() - 1) {
		System.out.print(input.substring(start, start + 1).toUpperCase() + input.substring(start + 1, i + 1));
	    }
	}
    }
}
