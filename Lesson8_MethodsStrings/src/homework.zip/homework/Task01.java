package homework;

import java.util.Scanner;

public class Task01 {
    public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);

	System.out.println("Enter two strings that contain up to 40 symbols and have small and capital letter");

	String str1 = sc.next();
	String str2 = sc.next();

	while (!hasSmallAndCapiralLetter(str1) || !lengthCheck(str1) ||
		!hasSmallAndCapiralLetter(str2) || !lengthCheck(str2)) {
	    System.out.print("Enter strings: ");
	    str1 = sc.nextLine();
	    str2 = sc.nextLine();
	}

	System.out.print(str1.toUpperCase());
	System.out.print(" ");
	System.out.print(str1.toLowerCase());
	System.out.print(" ");
	System.out.print(str2.toUpperCase());
	System.out.print(" ");
	System.out.print(str2.toLowerCase());
    }

    static boolean lengthCheck(String str) {
	if (str.length() <= 40) {
	    return true;
	} else {
	    return false;
	}
    }

    static boolean hasSmallAndCapiralLetter(String str) {

	boolean hasSmallLetter = !str.equals(str.toUpperCase());
	boolean hasCapitalLetter = !str.equals(str.toLowerCase());

	if (hasSmallLetter && hasCapitalLetter) {
	    return true;
	} else {
	    return false;
	}
    }
}
