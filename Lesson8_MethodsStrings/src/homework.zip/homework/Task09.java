package homework;

public class Task09 {
    public static void main(String[] args) {
	String input = "asd-12sdf45-56asdf100";

    }
}
