package homework.notepad.interfaces;

public interface IЕlectronicDevice {

    void start();

    void stop();

    boolean isStarted();

}
